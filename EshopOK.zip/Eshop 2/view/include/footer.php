<footer class="footer">


<div class="container">
    <?php
    echo "<p>- T-Shop -</p>
          <a href='$root/view/mention.php' > Mentions Legales </a>
          <br>
          <a href='$root/view/admin/share.php?sharable=twitter' > Twitter </a>
          <a href='$root/view/admin/share.php?sharable=facebook' > Facebook </a>
          <a href='$root/view/admin/share.php?sharable=linkedin' > linkedin </a>"
        ;
    ?>
</div>
    <div class="text">
        <p>
        T-Shop est un site créé dans le cadre du cours de Web-Dynamique dispensé par A.MBayo 
        <br> Groupe 2 : Anderson Thibault, Deleclos Xavier, Racquez, Ronald & Rosier Audric
        <br><br>- IFOSUP 2021-22 -
        </p>
    </div>
</footer>