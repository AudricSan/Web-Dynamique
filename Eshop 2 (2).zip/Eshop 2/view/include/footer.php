<footer>
    <?php
    echo "<a href='$root/view/mention.php' > Mention Legale </a>";
    ?>

    <div>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate cumque suscipit est unde qui autem natus ipsum assumenda pariatur eveniet fugit cum repellat aperiam et ipsa magni, odio ut reiciendis.
    </div>
</footer>