<footer>
    <a href="" > LINK </a>
    <div>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptate deleniti voluptatum sequi numquam! Perspiciatis asperiores rerum magni soluta corporis atque officiis assumenda earum laborum! Maiores ducimus deleniti natus nostrum aliquid.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptate deleniti voluptatum sequi numquam! Perspiciatis asperiores rerum magni soluta corporis atque officiis assumenda earum laborum! Maiores ducimus deleniti natus nostrum aliquid.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptate deleniti voluptatum sequi numquam! Perspiciatis asperiores rerum magni soluta corporis atque officiis assumenda earum laborum! Maiores ducimus deleniti natus nostrum aliquid.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptate deleniti voluptatum sequi numquam! Perspiciatis asperiores rerum magni soluta corporis atque officiis assumenda earum laborum! Maiores ducimus deleniti natus nostrum aliquid.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptate deleniti voluptatum sequi numquam! Perspiciatis asperiores rerum magni soluta corporis atque officiis assumenda earum laborum! Maiores ducimus deleniti natus nostrum aliquid.
    </div>
</footer>