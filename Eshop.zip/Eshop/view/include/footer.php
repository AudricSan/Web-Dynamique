</body>

<footer>
    <div class="footer">
        <ul>
            <li><a> CGU </a></li>
            <li><a href="legal/legal.php"> Legal </a></li>
        </ul>

    </div>
</footer>

<script src="js/reload.js"></script>
<script src="js/hover.js"></script>

</html>-