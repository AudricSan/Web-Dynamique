<?php

$couocu = $_SERVER;
var_dump($couocu);

$dir = "http://web-dynamique/Eshop/view/img/";

?>



